package com.automation.core.config;

public class WebSettings {
    private String defaultBrowser;
    private
    String baseUrl;
    private
    BrowserSettings chrome;
    private
    BrowserSettings firefox;
    private
    BrowserSettings edge;
    private
    BrowserSettings opera;
    private
    BrowserSettings internetExplorer;
    private
    BrowserSettings safari;
    private
    int elementWaitTimeout;
    private boolean enableProxy;
    private String remoteUrl;
    private String runMode;

    public String getBaseUrl() {
        return baseUrl;
    }

    public BrowserSettings getChrome() {
        return chrome;
    }

    public BrowserSettings getFirefox() {
        return firefox;
    }

    public BrowserSettings getEdge() {
        return edge;
    }

    public BrowserSettings getOpera() {
        return opera;
    }

    public BrowserSettings getInternetExplorer() {
        return internetExplorer;
    }

    public BrowserSettings getSafari() {
        return safari;
    }

    public int getElementWaitTimeout() {

        return elementWaitTimeout;
    }

    public String getDefaultBrowser() {
        return defaultBrowser;
    }

    public boolean isEnableProxy() {
        return enableProxy;
    }

    public String getRemoteUrl() {
        return remoteUrl;
    }

    public String getRunMode() {
        return runMode;
    }
}