package com.automation.core.enums;

import java.util.Arrays;

public enum Browser {
    CHROME("chrome"),
    CHROME_HEADLESS("chrome"),
    FIREFOX("firefox"),
    FIREFOX_HEADLESS("firefox"),
    EDGE("edge"),
    EDGE_HEADLESS("edge"),
    OPERA("opera"),
    SAFARI("safari"),
    INTERNET_EXPLORER("ie");

    private final String value;

    Browser(String value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return value;
    }

    // --- Main flexible method ---
    public static Browser fromText(String text, Browser defaultBrowser) {
        if (text == null || text.isEmpty()) {
            return defaultBrowser;
        }
        return Arrays.stream(values())
                .filter(b -> b.name().equalsIgnoreCase(text) || b.value.equalsIgnoreCase(text))
                .findFirst()
                .orElse(defaultBrowser);
    }

    // --- Convenience method, keeps backward compatibility ---
    public static Browser fromText(String text) {
        return fromText(text, Browser.CHROME); // fallback only if nothing provided
    }

    public boolean isHeadless() {
        return this.name().contains("HEADLESS");
    }}


