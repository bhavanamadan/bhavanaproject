package com.automation.core.strategies;

import com.automation.core.elements.Element;

public class LambdaClickStrategy implements ClickStrategy {

    private final ClickStrategy strategy;

    public LambdaClickStrategy(ClickStrategy strategy) {
        this.strategy = strategy;
    }

    @Override
    public void click(Element element,String logMessage) {
        strategy.click(element,logMessage);
    }
}
