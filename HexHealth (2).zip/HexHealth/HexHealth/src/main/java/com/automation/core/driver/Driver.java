package com.automation.core.driver;
import com.automation.core.enums.Browser;

public abstract class Driver {
    public abstract void start(Browser browser);

    public abstract void quit();

    public abstract void goToUrl(String url) throws InterruptedException;

}
