package com.automation.core.strategies;

import com.automation.core.elements.Element;
import com.automation.core.reportutil.ExtentTestManager;
import com.relevantcodes.extentreports.LogStatus;

public class LoggingClickStrategy implements ClickStrategy {
    private final ClickStrategy wrapped;

    public LoggingClickStrategy(ClickStrategy wrapped) {
        this.wrapped = wrapped;
    }

    @Override
    public void click(Element element, String logMessage) {
        try {
            wrapped.click(element, logMessage);
            ExtentTestManager.getTest().log(LogStatus.INFO, logMessage + " -> Click succeeded on " + element);
        } catch (Exception e) {
            ExtentTestManager.getTest().log(LogStatus.FAIL, logMessage + " -> Click failed on " + element);
            throw e;
        }
    }
}
