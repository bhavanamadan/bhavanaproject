package com.automation.core.brands.HE.tests;

import com.automation.core.annotations.ExecutionBrowser;
import com.automation.core.base.BaseTest;

import com.automation.core.elements.Element;
import com.automation.core.enums.Browser;
import com.automation.core.enums.BrowserBehavior;

import com.automation.core.extensions.ElementFindServiceExtensions;
import com.automation.core.extensions.ElementWaitServiceExtensions;
import com.automation.core.services.ElementFindService;
import com.automation.core.services.ElementWaitService;
import com.automation.core.strategies.ClickStrategy;
import org.testng.annotations.Test;


public class HomePageTest extends BaseTest {
//    private final ElementFindService findService;
//    private final ElementWaitService waitService;
//    private final ClickStrategy clickStrategy;

    @Test
    @ExecutionBrowser(browser = Browser.CHROME, browserBehavior = BrowserBehavior.RESTART_EVERY_TIME)
    public void launchingBrowser() throws InterruptedException {  // the test's code
        // Use the browser from the annotation
        getDriver().goToUrl(webSettings.getBaseUrl());
//        clickMegaMenu();
    }


//    public HomePageTest(ElementFindService findService, ElementWaitService waitService, ClickStrategy clickStrategy) {
//        this.findService = findService;
//        this.waitService = waitService;
//        this.clickStrategy = clickStrategy;
//    }


//    public void clickMegaMenu() {
//        Element megaMenu = ElementFindServiceExtensions.findByXPath(findService, "//a[@class='megamenu']");
//        ElementWaitServiceExtensions.waitUntilClickable(waitService, megaMenu, 2);
//        clickStrategy.click(megaMenu, "Clicked on a megamenu");
//
//    }

}