package com.automation.core.strategies;

import org.openqa.selenium.WebElement;

public interface SendKeysStrategy {
    void sendKeys(WebElement element, String value, String fieldName);

}
