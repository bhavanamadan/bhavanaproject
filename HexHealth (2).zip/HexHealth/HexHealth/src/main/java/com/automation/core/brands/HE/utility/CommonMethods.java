package com.automation.core.brands.HE.utility;

import com.relevantcodes.extentreports.LogStatus;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.SkipException;
import org.testng.TestNGException;
import org.testng.asserts.SoftAssert;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Set;

import static com.automation.core.reportutil.ExtentTestManager.getTest;
import static org.testng.Assert.fail;


public class CommonMethods extends ElementControl {

    public CommonMethods(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

private static final String ATTRIBUTE ="class";
    public boolean clearCustom(WebElement element) {
        element.clear();
        return true;
    }

    public void searchAndClickCategoryCTA(String category, String domainUrl) throws InterruptedException {

        search(category, domainUrl);
        if (startConsultationCta.getAttribute(ATTRIBUTE).contains("inactive")) {
            getTest().log(LogStatus.INFO, "Consultation CTA is seen inactive: skipping further execution");
            throw new SkipException("Skipping test as the Consultation CTA is inactive.");
        }
        scrollUptoPixels();
        clickCustomRetry(startConsultationCta,"Clicked on consultation CTA: product page");
        waitForPageLoad();
        if (driver.getCurrentUrl().contains("uk")) {
            clickCustomRetry(startConsultationCtaCategory,"Clicked on category page: category page");
            handleCheckoutLoader();
        }
    }

    public void search(String category, String domainUrl) throws InterruptedException {
        String exceptionMsg = "Result for searched string not found";
        clickCustomRetry(homeBannerSearch, "Clicked on a home banner search field");
        sendKeysUsingJavaScript(homeBannerSearch, category);
        Thread.sleep(200);
        int retries = 5;  // Number of retries
        while (retries > 0) {
            try {
                // Wait for elements to become visible
                createDynamicWait(50).until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath(CommonLocators.BANNERSRCHLIST)));

                // Locate the list of elements
                java.util.List<WebElement> list = driver.findElements(By.xpath(CommonLocators.BANNERSRCHLIST));
                boolean stringToSearch = false;

                // Iterate through the list to find the category
                for (WebElement webElement : list) {
                    if (webElement.getText().contains(category)) {
                        clickCustomRetry(webElement, "Clicked on required searched result:" + category);
                       waitForPageLoad();
                        stringToSearch = true;
                        break;
                    }
                }

                if (!stringToSearch) {
                    getTest().log(LogStatus.ERROR, "Searched string not found in the suggestion list", category);
                    throw new SkipException(exceptionMsg);

                } else {
                    int statusCode = redirectionVerification();
                    if (!driver.getCurrentUrl().equalsIgnoreCase(domainUrl)) {
                        if (statusCode != 0) {
                            getTest().log(LogStatus.ERROR, "Redirecting user to " + statusCode);
                            throw new SkipException("Skipping this test case as it is redirecting to " + statusCode);
                        }

                    } else {
                        getTest().log(LogStatus.ERROR, "Redirecting user to home page:");
                        throw new SkipException("Skipping this test case as it is redirecting to " + driver.getCurrentUrl());

                    }
                }
                break;

            } catch (StaleElementReferenceException e) {
                // Log and retry in case of StaleElementReferenceException

                retries--;  // Decrement retry count
                if (retries == 0) {
                    // Log failure after max retries
                    getTest().log(LogStatus.ERROR, "StaleElementReferenceException after retries", e.getMessage());
                    fail();
                }
            } catch (NoSuchElementException e) {
                getTest().log(LogStatus.WARNING, exceptionMsg);
                throw new SkipException("Result for searched string not found");
            }
        }

    }

    /*
    Javascript Scrolling Methods
     */


    public boolean scrollUptoPixelsInUpwardDirection() {
        JavascriptExecutor executor = (JavascriptExecutor) driver;
        executor.executeScript("window.scrollBy(0,-440)", "");
        return true;
    }


    public boolean moveToElement(WebElement element) {
        Actions act = new Actions(driver);
        act.moveToElement(element).perform();
        return true;
    }


    private boolean isSelected(By locator) {
        return driver.findElement(locator).isSelected();
    }

    private boolean isDeSelected(By locator) {
        return driver.findElement(locator).isSelected();
    }

    public boolean clickUsingAction(WebElement element) {
        Actions actions = new Actions(driver);
        actions.moveToElement(element).click().build().perform();
        return true;
    }


    public void clickWithRetry(WebElement element, int maxRetries) {
        int retries = 0;
        boolean clicked = false;

        while (retries < maxRetries) {
            try {
                element.click();  // Attempt to click the element
                clicked = true;   // Set clicked to true if successful
                break;            // Exit loop if click is successful
            } catch (StaleElementReferenceException e) {
                retries++;  // Increment retry count
                // Optionally re-locate the element if needed
                if (retries == maxRetries) {
                    getTest().log(LogStatus.ERROR, "StaleElementReferenceException after retries");
                }
            }
        }

        if (!clicked) {
            throw new SkipException("Unable to click the element after " + maxRetries + " retries.");
        }
    }


    public void sendKeysUsingJavaScript(WebElement element, String str) {
        waitForElementToGetClickable(element, 40);
        javascriptExecutorClick(element);
        element.sendKeys(str);
    }

    public void verifyTitleSoftAssert(String expectedTitle, SoftAssert softAssert) {
        if (!getTitleCustom().equals(expectedTitle)) {
            softAssert.assertEquals(getTitleCustom(), expectedTitle);
            getTest().log(LogStatus.FAIL, "Title is different");
            getTest().log(LogStatus.INFO, "Expected Title : " + expectedTitle);
            getTest().log(LogStatus.INFO, "Actual Title : " + driver.getTitle());
        } else {
            getTest().log(LogStatus.PASS, "Title : " + getTitleCustom());
            getTest().log(LogStatus.INFO, "Title is verified");
        }

    }

    public void verifyDescriptionSoftAssert(String expectedDescription,SoftAssert softAssert) {
        String actualDescription = description.getAttribute("content");
        if (!actualDescription.equals(expectedDescription)) {
            softAssert.assertEquals(actualDescription, expectedDescription);
            getTest().log(LogStatus.FAIL, "Description is different");
            getTest().log(LogStatus.INFO, "Expected Description : " + expectedDescription);
            getTest().log(LogStatus.INFO, "Actual Description : " + actualDescription);
        } else {
            getTest().log(LogStatus.PASS, "Description : " + actualDescription);
            getTest().log(LogStatus.INFO, "Description is verified");
        }
    }


    public WebElement getElement() {
        return driver.findElement(By.cssSelector("div.PagHead"));
    }

    public void waitForPageLoad() {
        createDynamicWait(10).until(webDriver -> ((JavascriptExecutor) webDriver).executeScript("return document.readyState").equals("complete"));
    }

    // Opens a link in a new tab using JavaScript
    public void openLinkInNewTab(WebElement element, String elementText, String attribute) {
        String elementUrl = element.getAttribute(attribute);
        if (elementUrl != null && !elementUrl.isEmpty()) {
            ((JavascriptExecutor) driver).executeScript("window.open(arguments[0], '_blank');", elementUrl);
            getTest().log(LogStatus.INFO, "Clicked on :", elementText);
        } else {
            getTest().log(LogStatus.WARNING, "Link is missing an href attribute: " + element.getText());
            throw new TestNGException("Skipping this test case as " + attribute + " is not found");
        }
    }

    // Switches to the newly opened tab
    public boolean switchToNewTab() {
        String originalTab = driver.getWindowHandle();
        Set<String> allTabs = driver.getWindowHandles();

        // Wait briefly for a new tab to open (adjust wait time if necessary)
        long end = System.currentTimeMillis() + 2000; // 2 seconds wait time
        while (System.currentTimeMillis() < end && allTabs.size() <= 1) {
            allTabs = driver.getWindowHandles();
        }

        // Check if a new tab is available and switch to it
        for (String tab : allTabs) {
            if (!tab.equals(originalTab)) {
                driver.switchTo().window(tab);
                return true; // Successfully switched to new tab
            }
        }

        // Log or handle the case when no new tab is found
        getTest().log(LogStatus.WARNING, "No new tab found to switch to.");
        return false; // Indicate that the switch was unsuccessful
    }

    // Verifies if the current URL contains the specified text
    public boolean verifyCurrentUrlContains(String text) {
        return driver.getCurrentUrl().contains(text);
    }

    public void verifyText(String expected, By locator, String logMessage) {
        try {
            createDynamicWait(20).until(ExpectedConditions.visibilityOfElementLocated(locator));
            String actual = driver.findElement(locator).getText();
            if (expected.equalsIgnoreCase(actual)) {
                getTest().log(LogStatus.INFO, logMessage, actual);
            } else {
                getTest().log(LogStatus.WARNING, logMessage, actual);
            }

        } catch (TimeoutException e) {
            getTest().log(LogStatus.INFO, "Element is not visible within given time.");
        } catch (NoSuchElementException e) {
            getTest().log(LogStatus.INFO, "Element is not found");
        }
    }

    public int getStatusCode(String urlString) {
        try {
            URL url = new URL(urlString);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.connect();
            return connection.getResponseCode();
        } catch (Exception e) {
            e.printStackTrace();
            return -1;
        }
    }

    public int redirectionVerification() {
        String currentUrl = driver.getCurrentUrl();
        int statusCode = getStatusCode(currentUrl);
        int invalidStatusCode = 0;

        if (statusCode != 200) {
            invalidStatusCode = statusCode;  // Set success to false before throwing the exception
            getTest().log(LogStatus.ERROR, "Redirecting user to " + statusCode);

            // Log failure, return false, then throw the exception
            // You can log or do any other action before throwing the exception
        }

        return invalidStatusCode;
    }

    // Helper method to validate URL via HTTP GET request
    private boolean validateUrl(String url) throws IOException {
        if (url == null || url.isEmpty()) {
            throw new IllegalArgumentException("URL is null or empty.");
        }

        HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
        connection.setRequestMethod("GET");
        connection.connect();

        int responseCode = connection.getResponseCode();
        connection.disconnect();

        return responseCode == 200; // Return true if HTTP response is 200 (OK)
    }

    // Method to verify CDN URL by sending an HTTP GET request
    public void cdnUrlVerification(String elementName, By locator) {
        try {
            // Wait for the element to be visible
            createDynamicWait(15).until(ExpectedConditions.visibilityOfElementLocated(locator));

            // Locate the element and fetch the URL
            WebElement urlElement = driver.findElement(locator);
            String url = urlElement.getAttribute("href");

            // Ensure the URL starts with a protocol
            if (url != null && url.startsWith("//")) {
                url = "https:" + url; // Assume HTTPS if protocol is missing
            }

            // Validate the URL through an HTTP connection
            if (validateUrl(url)) {
                getTest().log(LogStatus.PASS, elementName + " URL is valid with HTTP response code 200.");
            } else {
                getTest().log(LogStatus.WARNING, elementName + " URL returned a non-200 HTTP response.");
            }

        } catch (NoSuchElementException e) {
            getTest().log(LogStatus.WARNING, elementName + " is not found: " + e.getMessage());
        } catch (IOException e) {
            getTest().log(LogStatus.INFO, "Error during URL verification: " + e.getMessage());
        }
    }


}




