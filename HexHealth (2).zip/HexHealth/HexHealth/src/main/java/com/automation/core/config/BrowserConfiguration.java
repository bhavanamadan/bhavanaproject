package com.automation.core.config;

import com.automation.core.enums.Browser;
import com.automation.core.enums.BrowserBehavior;

public class BrowserConfiguration {
    private final Browser browser;
    private final BrowserBehavior browserBehavior;

    public BrowserConfiguration(Browser browser, BrowserBehavior browserBehavior) {
        this.browser = browser;
        this.browserBehavior = browserBehavior;
    }

    public Browser getBrowser() {
        return browser;
    }

    public BrowserBehavior getBrowserBehavior() {
        return browserBehavior;
    }
}
