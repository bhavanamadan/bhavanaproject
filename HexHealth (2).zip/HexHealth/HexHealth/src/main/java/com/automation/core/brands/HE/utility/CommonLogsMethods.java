package com.automation.core.brands.HE.utility;


import com.relevantcodes.extentreports.LogStatus;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import static com.automation.core.reportutil.ExtentTestManager.getTest;


public class CommonLogsMethods {


    ElementControl elementControl;

    public void assertEqualsAndLog(String actual, String expected) {
        Assert.assertEquals(expected, actual, " Text doesn't matched ");
        getTest().log(LogStatus.PASS, "Performed Verification: " + "Text matched");
    }

    public static void assertTrueAndLog(boolean condition, String actionDescription) {
        Assert.assertTrue(condition, actionDescription + " action failed");
        getTest().log(LogStatus.PASS, "Performed: " + actionDescription);
    }

    public static void assertTrueAndLogDetails(boolean condition, String actionDescription, String details) {
        Assert.assertTrue(condition, actionDescription + " action failed");
        getTest().log(LogStatus.PASS, "Performed: " + actionDescription, details);
    }

    public void sendKeysAndLogResult(WebElement element, String value, String logMessage,String fieldName) {
        try {
            elementControl.sendKeysCustom(element, value,fieldName);
            Assert.assertEquals(value, element.getAttribute("value"), "Value verification failed for " + logMessage);
            getTest().log(LogStatus.PASS, "Entered " + logMessage + " as : " + value);
        } catch (Exception e) {
            getTest().log(LogStatus.FAIL, "Unable to enter " + logMessage + " - " + e.getMessage());
            throw new AssertionError("Failed to enter " + logMessage);
        }
    }

    public void addTestDescription(String description, String category) {
        getTest().getTest().setName(description);
        getTest().assignCategory(category);
    }
}

