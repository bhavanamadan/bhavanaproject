package com.automation.core.brands.HE.utility;


import com.relevantcodes.extentreports.LogStatus;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.SkipException;
import org.testng.asserts.SoftAssert;

import java.time.Duration;

import static com.automation.core.reportutil.ExtentTestManager.getTest;


public class ElementControl extends CommonLocators {


private final JavascriptExecutor js;
    public ElementControl(WebDriver driver) {
        super(driver);
        this.js = (JavascriptExecutor) driver;
    }

    /*
      Explicit wait
       */
    public static WebDriverWait createDynamicWait(long timeoutInSeconds) {
        return new WebDriverWait(driver, Duration.ofSeconds(timeoutInSeconds));
    }

    public static boolean clickCustom(WebElement element) {
        createDynamicWait(20).until(ExpectedConditions.visibilityOf(element));
        createDynamicWait(10).until(ExpectedConditions.elementToBeClickable(element));
        element.click();
        return true;
    }
    public void javascriptExecutorClick(WebElement element) {
        js.executeScript("arguments[0].click();", element);

    }
    public boolean javascriptExecutorClickCustom(WebElement element) {

        waitForElementToGetClickable(element, 30);
        js.executeScript("arguments[0].click();", element);
        return true;
    }

//    Explicit wait

    public void waitForVisibilityOfElement(WebElement element, int timeout) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
        wait.until(ExpectedConditions.visibilityOf(element));

    }

    public void waitForElementToGetClickable(WebElement element, int timeout) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
        wait.until(ExpectedConditions.elementToBeClickable(element));

    }

    /*
   Javascript Scrolling Methods
     */
    public void scrollUptoPixels() {
        js.executeScript("window.scrollBy(0,340)", "");
    }

    public void scrollUptoEndOfThePage() {
        js.executeScript("window.scrollBy(0,document.body.scrollHeight)");

    }

    public void scrollUpToWebElement(WebElement element) {
        waitForElementToGetClickable(element, 50);
        js.executeScript("arguments[0]. scrollIntoView();", element);

    }

    public String getTitleCustom() {
        return driver.getTitle();
    }


    public String getAttributeCustom(WebElement element, String attributeName) {
        getTest().log(LogStatus.PASS, "Text of " + attributeName + ":" + "\n" + element.getAttribute(attributeName));

        return element.getAttribute(attributeName);
    }

    public static void customAssertEquals(String expectedTxt, String actualTxt, SoftAssert softAssert) {
        if (!expectedTxt.equals(actualTxt)) {
            softAssert.assertEquals(expectedTxt, actualTxt);
            getTest().log(LogStatus.FAIL, "Text is different");
            getTest().log(LogStatus.INFO, "Expected Text : " + expectedTxt);
            getTest().log(LogStatus.INFO, "Actual Text : " + actualTxt);
        } else getTest().log(LogStatus.PASS, "Text : " + expectedTxt);
        getTest().log(LogStatus.INFO, "Text is verified");

    }
    private void handleElementNotInteractableLogMsg(WebElement element, String logMessage) throws InterruptedException {
        boolean clickSuccessful = false;
        int attempts = 0;
        while (attempts < 5) {
            try {
                element.click();
                clickSuccessful = true;
                handleCheckoutLoader();
                getTest().log(LogStatus.INFO, logMessage);
                break; // Click succeeded
            } catch (ElementClickInterceptedException e) {
                Thread.sleep(200);
                getTest().log(LogStatus.INFO, "Attempt " + (attempts + 1) + ": ElementClickInterceptedException - Retrying...");
                attempts++;
            }
        }
        // Check if click was successful after all attempts
        if (!clickSuccessful) {
            getTest().log(LogStatus.ERROR, "Failed to click on element after " + attempts + " attempts.");
            throw new ElementClickInterceptedException("Failed to click on element after " + attempts + " attempts.");
        }
    }
    public void clickCustomRetry(WebElement element, String logMessage) {

        try {
            createDynamicWait(20).until(ExpectedConditions.visibilityOf(element));
            createDynamicWait(20).until(ExpectedConditions.elementToBeClickable(element));
            handleElementNotInteractableLogMsg(element, logMessage);
        } catch (TimeoutException | InterruptedException e) {
            /* Clean up whatever needs to be handled before interrupting  */
            Thread.currentThread().interrupt();
            throw new SkipException("TimeoutException: Element was not visible or clickable in the given time.", e);
        }
    }
    public void sendKeysCustom(WebElement element, String str, String fieldName) {
        waitForElementToGetClickable(element, 70);
        element.sendKeys(str);
        getTest().log(LogStatus.INFO,"Entered text:"+str,fieldName);

    }
    // Helper method to check if an element with a specific attribute is present
    public boolean isElementPresent(By selector, String attributeName, String value) {
        WebElement element = driver.findElement(selector);
        return element.getAttribute(attributeName).contains(value);
    }
    // Method to locate an element safely(mAKE IT COMMON, SHIFT TO ELEMENT CONTROL)
    public WebElement locateElement(By locator) {
        try {
            return driver.findElement(locator);
        } catch (NoSuchElementException e) {
            return null;
        }
    }
    public static boolean isEnabledCustom(WebElement element) {
        try {
            createDynamicWait(30).until(ExpectedConditions.visibilityOf(element));
            return element.isEnabled();
        } catch (TimeoutException e) {
            getTest().log(LogStatus.INFO, "Element is not visible within given timeout", e.getMessage());
            return false;
        }

    }
    public boolean isElementDisplayed(By locator) {
        try {

            WebElement element = driver.findElement(locator);
            return element.isDisplayed();
        } catch (NoSuchElementException e) {
            return false;
        }
    }
    public void handleCheckoutLoader() {
        try {
            createDynamicWait(40).until(ExpectedConditions.invisibilityOfElementLocated(checkoutLoader));
        } catch (TimeoutException e) {
            throw new SkipException("Checkout loader is not invisible within given timeout");
        }

    }
}

