package com.automation.core.config;

public class EnvironmentConfig {
    private final String baseUrl;
    private final String browser;
    private final int timeout;
    private final boolean headless;

    public EnvironmentConfig(String baseUrl, String browser, int timeout, boolean headless) {
        this.baseUrl = baseUrl;
        this.browser = browser;
        this.timeout = timeout;
        this.headless = headless;
    }

    public String getBaseUrl() {
        return baseUrl;
    }

    public String getBrowser() {
        return browser;
    }

    public int getTimeout() {
        return timeout;
    }

    public boolean isHeadless() {
        return headless;
    }
}