package com.automation.core.base;

import com.automation.core.config.ConfigurationService;
import com.automation.core.config.WebSettings;
import com.automation.core.driver.Driver;
import com.automation.core.driver.LoggingDriver;
import com.automation.core.driver.WebCoreDriver;
import com.automation.core.observers.BrowserLaunchTestBehaviorObserver;

import net.lightbody.bmp.BrowserMobProxy;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;

public class BaseTest {


//    need to use driver.remove after method and threadlocal remove for clean up after method or after suite

    protected static final WebSettings webSettings = ConfigurationService.get(WebSettings.class);

    private static final ThreadLocal<TestExecutionSubject> executionSubject;
    private static final ThreadLocal<Driver> driver;
    private static final ThreadLocal<BrowserMobProxy> proxy;

    private ITestResult result;


    static {
        executionSubject = new ThreadLocal<>();
        executionSubject.set(new ExecutionSubject());
        driver = new ThreadLocal<>();
        driver.set(new LoggingDriver(new WebCoreDriver()));
        new BrowserLaunchTestBehaviorObserver(executionSubject.get(), driver.get());
        proxy = new ThreadLocal<>();
    }

    public String getTestName() {
        return getTestResult().getTestName();
    }

    public void setTestResult(ITestResult result) {
        this.result = result;
    }

    public ITestResult getTestResult() {
        return result;

    }

    public Driver getDriver() {
        return driver.get();
    }

//    @BeforeSuite
//    public void beforeSuite() {
//        ConfigManager.loadConfig(System.getProperty("env", "stg"));
//        EnvironmentConfig config = ConfigManager.getConfig();
//        String url = config.getBaseUrl();
//
//    }

    @AfterSuite

    public void afterSuite() {
        if (driver.get() != null) {
            driver.get().quit();
        }
    }

    @BeforeMethod

    public void beforeMethod(ITestResult result) throws NoSuchMethodException {
        setTestResult(result);
        var testClass = this.getClass();
        var methodInfo = testClass.getMethod(getTestResult().getMethod().getMethodName());
        executionSubject.get().preTestInit(getTestResult(), methodInfo);
        // Ensure driver is initialized for the current thread
        if (driver.get() == null) {
            driver.set(new LoggingDriver(new WebCoreDriver()));
        }

        // Launch the browser

//        getDriver().start(webSettings.getDefaultBrowser());
//        getDriver().goToUrl(url);  // You need a launchBrowser() method in your Driver class

        testInit();
        executionSubject.get().postTestInit(getTestResult(), methodInfo);
    }

    @AfterMethod

    public void afterMethod() throws NoSuchMethodException {
        var testClass = this.getClass();
        var methodInfo = testClass.getMethod(getTestResult().getMethod().getMethodName());
        executionSubject.get().preTestCleanup(getTestResult(), methodInfo);
        testCleanup();
        executionSubject.get().postTestCleanup(getTestResult(), methodInfo);
        executionSubject.remove();
        driver.remove();
        proxy.remove();
    }

    protected void testInit() {


    }

    protected void testCleanup() {
    }
}