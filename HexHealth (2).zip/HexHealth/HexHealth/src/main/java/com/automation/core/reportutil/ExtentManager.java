package com.automation.core.reportutil;

import com.relevantcodes.extentreports.ExtentReports;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ExtentManager {

    private ExtentManager() {}

    private static ExtentReports extent;

    public static synchronized ExtentReports getReporter() {
        if (extent == null) {
            String workingDir = System.getProperty("user.dir");
            String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
            String reportDir = workingDir + File.separator + "reports";
            new File(reportDir).mkdirs(); // Create reports folder if not exists
            String reportPath = reportDir + File.separator + "Automation_Report_" + timestamp + ".html";

            extent = new ExtentReports(reportPath, true);

            // Optional: Add system info
            extent.addSystemInfo("OS", System.getProperty("os.name"));
            extent.addSystemInfo("Java Version", System.getProperty("java.version"));
            extent.addSystemInfo("User", System.getProperty("user.name"));

            // Optional: Report configuration
            // extent.loadConfig(new File(workingDir + File.separator + "extent-config.xml"));
        }
        return extent;
    }
}
