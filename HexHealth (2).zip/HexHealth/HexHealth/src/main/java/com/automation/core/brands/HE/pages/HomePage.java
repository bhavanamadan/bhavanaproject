package com.automation.core.brands.HE.pages;

import com.automation.core.base.BaseTest;
import com.automation.core.driver.Driver;
import com.automation.core.elements.Element;
import com.automation.core.extensions.ElementClickServiceExtensions;
import com.automation.core.extensions.ElementFindServiceExtensions;
import com.automation.core.extensions.ElementWaitServiceExtensions;
import com.automation.core.services.ElementFindService;
import com.automation.core.services.ElementWaitService;
import com.automation.core.strategies.ClickStrategy;

public class HomePage extends BaseTest {


    private final ElementFindService findService;
    private final Driver driver;
    private final ElementWaitService waitService;
    private final ClickStrategy clickStrategy;

    public HomePage(ElementFindService findService, ElementWaitService waitService, ClickStrategy clickStrategy, Driver driver) {
        this.driver = driver;
        this.findService = findService;
        this.waitService = waitService;
        this.clickStrategy = clickStrategy;
    }


    public void clickMegaMenu() {
        Element megaMenu = ElementFindServiceExtensions.findByXPath(findService, "//a[@class='megamenu']");
        ElementWaitServiceExtensions.waitUntilClickable(waitService, megaMenu, 2);
        clickStrategy.click(megaMenu, "Clicked on a megamenu");

    }
}
