package com.automation.core.extensions;

import com.automation.core.driver.Driver;
import com.automation.core.driver.WebCoreDriver;
import com.automation.core.elements.Element;
import com.automation.core.strategies.LambdaClickStrategy;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

public class ElementClickServiceExtensions {

    private final Driver driver;  // This is your decorator from BaseTest

    public ElementClickServiceExtensions(Driver driver) {
        this.driver = driver;
    }

    // Helper to get the actual Selenium WebDriver from your decorator
    private WebDriver getWebDriver() {
        if (!(driver instanceof WebCoreDriver)) {
            throw new IllegalStateException("Driver is not an instance of WebCoreDriver");
        }
        return ((WebCoreDriver) driver).getWebDriver();
    }

    public void defaultClick(Element element, String logMessage) {
        new LambdaClickStrategy((e, msg) -> e.getWrappedElement().click())
                .click(element, logMessage);
    }

    public void jsClick(Element element, String logMessage) {
        new LambdaClickStrategy((e, msg) -> {
            WebDriver wd = getWebDriver();
            ((JavascriptExecutor) wd).executeScript("arguments[0].click();", e.getWrappedElement());
        }).click(element, logMessage);
    }

    public void doubleClick(Element element, String logMessage) {
        new LambdaClickStrategy((e, msg) -> {
            WebDriver wd = getWebDriver();
            new Actions(wd).doubleClick(e.getWrappedElement()).perform();
        }).click(element, logMessage);
    }

    public void retryClick(Element element, int retries, String logMessage) {
        new LambdaClickStrategy((e, msg) -> {
            int attempts = 0;
            while (attempts < retries) {
                try {
                    e.getWrappedElement().click();
                    return;
                } catch (Exception ex) {
                    attempts++;
                    if (attempts == retries) {
                        throw new RuntimeException("Failed to click element after " + retries + " retries", ex);
                    }
                }
            }
        }).click(element, logMessage);
    }
}
