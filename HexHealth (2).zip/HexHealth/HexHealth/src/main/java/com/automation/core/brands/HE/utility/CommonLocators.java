package com.automation.core.brands.HE.utility;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class CommonLocators {
    protected static WebDriver driver;
    @FindBy(xpath = "//input[@id='homeBannerSearch']")
    public
    WebElement homeBannerSearch;
    @FindBy(css = "meta[name='description']:not([content=''])")
    public
    WebElement description;
    @FindBy(css = " div.ShipBox > a")
    public
    WebElement continueCtaBtnShippingOptions;
    @FindBy(xpath = "//div[contains(@class,\"AvlTrtRbx\") and ((contains(@style,\"table-cell\") or contains(@style,\"block\")) and not(contains(@style,\"none\")))]//div[contains(@class,\"OdrBx\")]//child::a[contains(@class,\"prodCta\")]")
    public
    WebElement startConsultationCta;
    @FindBy(xpath = "//div[contains(@class,\"consult_rbar\")]//a[contains(@class,\"startConsultation\")]")
    public
    WebElement startConsultationCtaCategory;
    @FindBy(xpath = "//div[@class=\"prodPackagesCont\"]//div[contains(@class, \"AvlTrtRbx\") and not(contains(@style, \"display:none\"))]//div[contains(@class,\"OdrBx\")]//div[@class=\"PriceBx\"]//a[contains(@class,\"prodCta\")]")
    public
    WebElement startConsultationCtaProduct;
    public static final String BANNERSRCHLIST = "//div[contains(@class,'bannerSearchPop')]//descendant::div//h2//a";
    public static final String DRWIDGET = "//div[@class=\"DoctReview\"]";
    public static final String PRODUCTLEAFLET = "//div[@class=\"product-leaflets-block\"]//div[not(contains(@style,\"display: none\"))]";
    public static final String CHILDFORODRBX = "//div[contains(@class, 'ProdBx')]//div[contains(@class, 'ProDsgBx')]//div//div[contains(@class, 'AvlTrtRbx')][contains(@style, 'display:table-cell') or @style='display:block']//div[contains(@class, 'OdrBx')]/*[1] | //div[contains(@class, 'ProdBx')]//div[contains(@class, 'ProDsgBx')]//div//div[contains(@class, 'AvlTrtRbx')][@style='display:block' or @style=\"display: table-cell;\"]/*[1]";
    public final By startConsultationCategory = By.xpath("//div[contains(@class, 'consult_rbar')]//a[contains(@class, 'startConsultation') or contains(text(), 'Book Video Consultation')]");
    public final By checkoutLoader = By.xpath("//form[@id=\"checkout\"]//div//div[contains(@class,\"checkoutLoader hidden\") and contains(@style,\"block;\")]");
    public final By tooltipTxtAreaExp = By.xpath("//div[contains(@class,\"ruleReason\") and not (contains(@style, \"display:none;\"))]//div[@class=\"inforbox\"]//textarea[contains(@class, \"ruleReasonBox\")]");
    public final By continueCta = By.xpath("//button[contains(@class,\"getNextQuestion\") or contains(@class,\"CtaBtn NxtIcn\")]");
    public final By orderNowCta = By.xpath("//div[contains(@class,\"newproduct\")and not(contains(@style,\"display:none;\"))]//div[contains(@class,\"acc__panel \") and@style= \"display: block;\"]//a[contains(@class,\"CtaBtn NxtIcn\") and not(contains(@class,\"OtStock\"))]");
    public final By requiredOrderNowCta = By.xpath("//div[contains(@class,\"otherTreatment\")]//div[contains(@class,\"newproduct\") and not(contains(@style,\"none\"))]//div[@class=\"acc__panel\" and (contains(@style,\"display: block\"))]//a[(contains(@class,\"CtaBtn NxtIcn\") and not(contains(@class,\"OtStock\")))]");
    public final By selectDiffTreatment = By.xpath("//div[contains(@class,\"orderSummery\")]//div[contains(@class,\"product-container\")]//span[contains(@class,\"sel-diff-treat\")]");
    protected String gpSrchBx = "//input[@type=\"text\" and@id=\"gppostcode\"]";

    public CommonLocators(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);

    }
}

