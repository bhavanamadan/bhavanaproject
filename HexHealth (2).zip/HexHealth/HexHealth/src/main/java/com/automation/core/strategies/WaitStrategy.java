package com.automation.core.strategies;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public interface WaitStrategy {
    WebElement apply(WebDriver driver, org.openqa.selenium.By locator);
}
