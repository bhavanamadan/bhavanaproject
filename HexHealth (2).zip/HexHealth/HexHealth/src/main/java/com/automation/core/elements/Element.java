package com.automation.core.elements;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Element {
        private final WebElement wrappedElement;

        public Element(WebElement wrappedElement) {
                this.wrappedElement = wrappedElement;
        }

        public WebElement getWrappedElement() {
                return wrappedElement;
        }

        @Override
        public String toString() {
                try {
                        return wrappedElement.toString() + " [text=" + wrappedElement.getText() + "]";
                } catch (Exception e) {
                        return wrappedElement.toString() + " [unable to get text]";
                }
        }
}
