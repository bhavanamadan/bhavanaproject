package com.automation.core.elements;

import com.automation.core.strategies.SendKeysStrategy;
import org.openqa.selenium.WebElement;


public class RetrySendKeys implements SendKeysStrategy {
    private final int attempts;

    public RetrySendKeys(int attempts) {
        this.attempts = attempts;
    }

    @Override
    public void sendKeys(WebElement element, String value, String fieldName) {
        for (int i = 0; i < attempts; i++) {
            try {
                element.clear();
                element.sendKeys(value);
                return;
            } catch (Exception e) {
                sleep(200);
            }
        }
        throw new RuntimeException("sendKeys failed after " + attempts + " attempts");
    }

    private void sleep(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}