package com.automation.core.extensions;

import com.automation.core.elements.Element;
import com.automation.core.services.ElementWaitService;
import com.automation.core.strategies.LambdaWaitStrategy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class ElementWaitServiceExtensions {

    private ElementWaitServiceExtensions() {
        throw new UnsupportedOperationException("Utility class");
    }

    public static Element waitUntilVisible(ElementWaitService service, Element element, int seconds) {
        return service.wait(element, new LambdaWaitStrategy((driver, locator) ->
                new WebDriverWait(driver, Duration.ofSeconds(seconds))
                        .until(ExpectedConditions.visibilityOfElementLocated(locator))
        ));
    }

    public static Element waitUntilClickable(ElementWaitService service, Element element, int seconds) {
        return service.wait(element, new LambdaWaitStrategy((driver, locator) ->
                new WebDriverWait(driver, Duration.ofSeconds(seconds))
                        .until(ExpectedConditions.elementToBeClickable(locator))
        ));
    }

    public static Element waitUntilPresent(ElementWaitService service, Element element, int seconds) {
        return service.wait(element, new LambdaWaitStrategy((driver, locator) ->
                new WebDriverWait(driver, Duration.ofSeconds(seconds))
                        .until(ExpectedConditions.presenceOfElementLocated(locator))
        ));
    }
}
