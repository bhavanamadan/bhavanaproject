package com.automation.core.strategies;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.function.BiFunction;

public class LambdaWaitStrategy implements WaitStrategy {

    private final BiFunction<WebDriver, By, WebElement> function;

    public LambdaWaitStrategy(BiFunction<WebDriver, By, WebElement> function) {
        this.function = function;
    }

    @Override
    public WebElement apply(WebDriver driver, By locator) {
        return function.apply(driver, locator);
    }
}
