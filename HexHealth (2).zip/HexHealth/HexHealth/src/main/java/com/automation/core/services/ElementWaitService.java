package com.automation.core.services;

import com.automation.core.elements.Element;
import com.automation.core.strategies.WaitStrategy;

public interface ElementWaitService {
    Element wait(Element element, WaitStrategy strategy);
}
