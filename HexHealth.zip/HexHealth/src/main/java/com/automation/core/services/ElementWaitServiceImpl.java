package com.automation.core.services;

import com.automation.core.driver.Driver;
import com.automation.core.elements.Element;
import com.automation.core.services.ElementWaitService;
import com.automation.core.strategies.LambdaWaitStrategy;
import com.automation.core.strategies.WaitStrategy;

public class ElementWaitServiceImpl implements ElementWaitService {

    private final Driver driver;

    public ElementWaitServiceImpl(Driver driver) {
        this.driver = driver;
    }

    @Override
    public Element wait(Element element, WaitStrategy strategy) {
        // Delegate the wait logic to the LambdaWaitStrategy
        return strategy.apply(driver, element);
    }
}
