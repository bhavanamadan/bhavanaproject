package com.automation.core.strategies;

import com.automation.core.elements.Element;
@FunctionalInterface
public interface ClickStrategy {
    void click(Element element,String logMessage);

}
