package com.automation.core.driver;

import com.automation.core.config.ConfigurationService;
import com.automation.core.config.WebSettings;
import com.automation.core.enums.Browser;
import io.github.bonigarcia.wdm.WebDriverManager;

import net.lightbody.bmp.BrowserMobProxy;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.client.ClientUtil;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;


public class WebCoreDriver extends Driver {

    private org.openqa.selenium.WebDriver webDriver;
    private WebDriverWait webDriverWait;


    @Override
    public void start(Browser browser) {
        BrowserMobProxy proxyServer;

        WebSettings settings = ConfigurationService.get(WebSettings.class);

        boolean enableProxy = settings.isEnableProxy();
        Proxy seleniumProxy = null;

        if (enableProxy) {
            proxyServer = new BrowserMobProxyServer();
            proxyServer.start(0);
            proxyServer.blacklistRequests(".*cookie-script\\.com/.*", 200); // block cookie popup
            seleniumProxy = ClientUtil.createSeleniumProxy(proxyServer);
            proxyServer.addRequestFilter((request, contents, messageInfo) -> {
                if (request.getUri().contains("cookie-script.com")) {
                    System.out.println("Blocked request to: " + request.getUri());
                }
                return null; // continue processing
            });
            if ("remote".equalsIgnoreCase(settings.getRunMode())) {
                try {
                    DesiredCapabilities caps = new DesiredCapabilities();
                    caps.setBrowserName(browser.toString().toLowerCase());
                    caps.setCapability("enableVNC", true);
                    caps.setCapability("enableVideo", false);

                    if (enableProxy && seleniumProxy != null) {
                        caps.setCapability("proxy", seleniumProxy);
                    }

                    webDriver = new RemoteWebDriver(new URL(settings.getRemoteUrl()), caps);
                } catch (MalformedURLException e) {
                    throw new RuntimeException("Invalid remote URL: " + settings.getRemoteUrl(), e);
                }
            } else {

                switch (browser) {
                    case CHROME -> {
                        WebDriverManager.chromedriver().setup();
                        ChromeOptions options = new ChromeOptions();
                        if (enableProxy && seleniumProxy != null) {
                            options.setProxy(seleniumProxy);
                        }
                        options.setAcceptInsecureCerts(true);
                        webDriver = new ChromeDriver(options);
                    }
                    case FIREFOX -> {
                        WebDriverManager.firefoxdriver().setup();
                        webDriver = new FirefoxDriver();
                    }
                    case EDGE -> {
                        WebDriverManager.edgedriver().setup();
                        webDriver = new EdgeDriver();
                    }
                    case OPERA -> WebDriverManager.operadriver().setup();

//                webDriver = new OperaDriver();
                    case SAFARI -> webDriver = new SafariDriver();
                    case INTERNET_EXPLORER -> {
                        WebDriverManager.iedriver().setup();
                        webDriver = new InternetExplorerDriver();
                    }
                    default -> throw new IllegalArgumentException(browser.name());
                }
                webDriverWait = new WebDriverWait(webDriver, Duration.ofSeconds(30));
            }
        }
    }
    @Override
    public WebDriver getWrappedDriver() {
        if (webDriver == null) {
            throw new IllegalStateException("WebDriver is not initialized yet");
        }
        return webDriver;
    }

    @Override
    public void quit() {
//        webDriver.quit();
        if (webDriver != null) {  // <-- add null check
            webDriver.quit();
            webDriver = null;      // optional: ensure driver is cleared
        }
    }

    @Override
    public void goToUrl(String url) throws InterruptedException {
        webDriver.navigate().to(url);
        webDriver.manage().window().maximize();
        Thread.sleep(2000);
    }

}