package com.automation.core.config;

public class BrowserSettings {
    private int pageLoadTimeout;
    private int scriptTimeout;

    public int getPageLoadTimeout() {
        return pageLoadTimeout;
    }

    public int getScriptTimeout() {
        return scriptTimeout;
    }
}
