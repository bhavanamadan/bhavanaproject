package com.automation.core.extensions;

import com.automation.core.driver.Driver;
import com.automation.core.elements.Element;
import com.automation.core.services.ElementWaitService;
import com.automation.core.strategies.LambdaWaitStrategy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class ElementWaitServiceExtensions {

    private ElementWaitServiceExtensions() {
        throw new UnsupportedOperationException("Utility class");
    }

    public static Element waitUntilVisible(ElementWaitService service, Element element, int seconds) {
        return service.wait(element, (drv, el) -> {
            WebDriverWait wait = new WebDriverWait(drv.getWrappedDriver(), Duration.ofSeconds(seconds));
            wait.until(ExpectedConditions.visibilityOf(el.getWrappedElement()));
            return el;
        });
    }

    public static Element waitUntilClickable(ElementWaitService service, Element element, int seconds) {
        return service.wait(element, (drv, el) -> {
            WebDriverWait wait = new WebDriverWait(drv.getWrappedDriver(), Duration.ofSeconds(seconds));
            wait.until(ExpectedConditions.elementToBeClickable(el.getWrappedElement()));
            return el;
        });
    }

    public static Element waitUntilPresent(ElementWaitService service, Element element, int seconds) {
        return service.wait(element, (drv, el) -> {
            WebDriverWait wait = new WebDriverWait(drv.getWrappedDriver(), Duration.ofSeconds(seconds));
            wait.until(ExpectedConditions.presenceOfElementLocated(el.getBy())); // assuming Element exposes By locator
            return el;
        });
    }
}
