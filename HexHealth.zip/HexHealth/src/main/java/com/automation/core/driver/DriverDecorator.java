package com.automation.core.driver;

import com.automation.core.enums.Browser;

import org.openqa.selenium.WebDriver;

public class DriverDecorator extends Driver {
    protected final Driver driver;

    public DriverDecorator(Driver driver) {
        this.driver = driver;
    }


    @Override
    public void start(Browser browser) {
        driver.start(browser);
    }

    @Override
    public void quit() {
        driver.quit();
    }

    @Override
    public void goToUrl(String url) throws InterruptedException {
        driver.goToUrl(url);
    }
    @Override
    public WebDriver getWrappedDriver() {
        // Delegate to the underlying driver (e.g., WebCoreDriver)
        return driver.getWrappedDriver();
    }
}
