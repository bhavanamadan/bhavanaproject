package com.automation.core.strategies;

import org.openqa.selenium.By;

import java.util.function.Supplier;

public class LambdaFindStrategy implements FindStrategy {
    private final Supplier<By> bySupplier;

    public LambdaFindStrategy(Supplier<By> bySupplier) {
        this.bySupplier = bySupplier;
    }

    @Override
    public By convert() {
        return bySupplier.get();
    }
}


