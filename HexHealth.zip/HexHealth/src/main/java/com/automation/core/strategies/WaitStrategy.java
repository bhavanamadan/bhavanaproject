package com.automation.core.strategies;

import com.automation.core.driver.Driver;
import com.automation.core.elements.Element;

@FunctionalInterface
public interface WaitStrategy {
    /**
     * Apply a wait on the given element using the provided driver.
     *
     * @param driver  The abstract driver (WebCoreDriver, LoggingDriver, etc.)
     * @param element The element wrapper
     * @return The same element after waiting
     */
    Element apply(Driver driver, Element element);
}
