package com.automation.core.reportutil;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class ExtentTestManager {

    private ExtentTestManager() {
    }

    // Thread-safe Map for parallel tests
    private static final Map<Long, ExtentTest> extentTestMap = new ConcurrentHashMap<>();
    private static final ExtentReports extent = ExtentManager.getReporter();

    public static synchronized ExtentTest getTest() {
        return extentTestMap.get(Thread.currentThread().threadId());
    }

    public static synchronized void startTest(String testName) {
        startTest(testName, "");
    }

    public static synchronized void startTest(String testName, String description) {
        ExtentTest test = extent.startTest(testName, description);
        extentTestMap.put(Thread.currentThread().threadId(), test);
    }

    public static synchronized void endTest() {
        ExtentTest test = extentTestMap.get(Thread.currentThread().threadId());
        if (test != null) {
            extent.endTest(test);
            extentTestMap.remove(Thread.currentThread().threadId());
        }
    }

    public static void flushReports() {
        extent.flush();
    }
}
