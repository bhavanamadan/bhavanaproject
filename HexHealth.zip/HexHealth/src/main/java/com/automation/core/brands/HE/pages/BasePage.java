package com.automation.core.brands.HE.pages;

import com.automation.core.services.ElementFindService;
import com.automation.core.services.ElementWaitService;
import com.automation.core.strategies.ClickStrategy;

public abstract class BasePage {

    protected final ElementFindService findService;
    protected final ElementWaitService waitService;
    protected final ClickStrategy clickStrategy;

    public BasePage(ElementFindService findService,
                    ElementWaitService waitService,
                    ClickStrategy clickStrategy) {
        this.findService = findService;
        this.waitService = waitService;
        this.clickStrategy = clickStrategy;
    }
}
