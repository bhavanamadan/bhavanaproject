package com.automation.core.extensions;

import com.automation.core.driver.Driver;
import com.automation.core.elements.Element;
import com.automation.core.strategies.LambdaClickStrategy;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

public class ElementClickServiceExtensions {

    private final Driver driver;  // Abstract driver

    public ElementClickServiceExtensions(Driver driver) {
        this.driver = driver;
    }

    // Use the abstract driver's getWrappedDriver method
    private WebDriver getWrappedDriver() {
        return driver.getWrappedDriver(); // Assumes every concrete driver implements this method
    }

    public void defaultClick(Element element, String logMessage) {
        new LambdaClickStrategy((e, msg) -> e.getWrappedElement().click())
                .click(element, logMessage);
    }

    public void jsClick(Element element, String logMessage) {
        new LambdaClickStrategy((e, msg) -> {
            ((JavascriptExecutor) getWrappedDriver())
                    .executeScript("arguments[0].click();", e.getWrappedElement());
        }).click(element, logMessage);
    }

    public void doubleClick(Element element, String logMessage) {
        new LambdaClickStrategy((e, msg) -> {
            new Actions(getWrappedDriver()).doubleClick(e.getWrappedElement()).perform();
        }).click(element, logMessage);
    }

    public void retryClick(Element element, int retries, String logMessage) {
        new LambdaClickStrategy((e, msg) -> {
            int attempts = 0;
            while (attempts < retries) {
                try {
                    e.getWrappedElement().click();
                    return;
                } catch (Exception ex) {
                    attempts++;
                    if (attempts == retries) {
                        throw new RuntimeException("Failed to click element after " + retries + " retries", ex);
                    }
                }
            }
        }).click(element, logMessage);
    }
}
