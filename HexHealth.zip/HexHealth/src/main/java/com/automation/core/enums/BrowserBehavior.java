package com.automation.core.enums;

public enum BrowserBehavior {
    NOT_SET, REUSE_IF_STARTED, RESTART_EVERY_TIME, RESTART_ON_FAIL,KEEP_OPEN
}
