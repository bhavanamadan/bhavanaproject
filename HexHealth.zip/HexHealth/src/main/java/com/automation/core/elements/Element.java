package com.automation.core.elements;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Element {
    private final WebElement wrappedElement;
    private final By locator;

    public Element(WebElement wrappedElement, By locator) {
        this.wrappedElement = wrappedElement;
        this.locator = locator;
    }

    public WebElement getWrappedElement() {
        return wrappedElement;
    }

    public By getBy() {
        return locator;
    }


    @Override
    public String toString() {
        try {
            return wrappedElement.toString() + " [text=" + wrappedElement.getText() + "]";
        } catch (Exception e) {
            return wrappedElement.toString() + " [unable to get text]";
        }
    }
}
