package com.automation.core.driver;
import com.automation.core.enums.Browser;
import org.openqa.selenium.WebDriver;

public abstract class Driver {
    public abstract void start(Browser browser);

    public abstract void quit();

    public abstract void goToUrl(String url) throws InterruptedException;
    public abstract WebDriver getWrappedDriver();

}
