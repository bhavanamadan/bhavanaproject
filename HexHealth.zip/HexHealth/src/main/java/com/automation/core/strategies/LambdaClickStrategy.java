package com.automation.core.strategies;

import com.automation.core.elements.Element;

import java.util.function.BiConsumer;

public class LambdaClickStrategy implements ClickStrategy {

    private final BiConsumer<Element, String> clickAction;

    public LambdaClickStrategy(BiConsumer<Element, String> clickAction) {
        this.clickAction = clickAction;
    }

    @Override
    public void click(Element element, String logMessage) {
        clickAction.accept(element, logMessage);
    }
}
