package com.automation.core.elements;


import com.automation.core.strategies.ScrollStrategy;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

public class ScrollIntoView implements ScrollStrategy {
    private final JavascriptExecutor js;

    public ScrollIntoView(JavascriptExecutor js) {
        this.js = js;
    }

    @Override
    public void scroll(WebElement element) {
        js.executeScript("arguments[0].scrollIntoView(true);", element);
    }
}