package com.automation.core.strategies;

import com.automation.core.driver.Driver;
import com.automation.core.elements.Element;

@FunctionalInterface
public interface LambdaWaitStrategy extends WaitStrategy {
    /**
     * Functional interface for lambda-based wait strategies
     */
    @Override
    Element apply(Driver driver, Element element);
}
