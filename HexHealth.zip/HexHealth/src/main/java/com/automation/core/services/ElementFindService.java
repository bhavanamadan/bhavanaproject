package com.automation.core.services;

import com.automation.core.elements.Element;
import com.automation.core.strategies.FindStrategy;

import java.util.List;

public interface ElementFindService {
    Element find(FindStrategy strategy);

    List<Element> findAll(FindStrategy strategy);
}

