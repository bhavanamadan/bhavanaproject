package com.automation.core.brands.HE.pages;

import com.automation.core.base.BaseTest;
import com.automation.core.driver.Driver;
import com.automation.core.elements.Element;
import com.automation.core.extensions.ElementClickServiceExtensions;
import com.automation.core.extensions.ElementFindServiceExtensions;
import com.automation.core.extensions.ElementWaitServiceExtensions;
import com.automation.core.services.ElementFindService;
import com.automation.core.services.ElementWaitService;
import com.automation.core.strategies.ClickStrategy;

public class HomePage extends BasePage {


    public HomePage(ElementFindService findService, ElementWaitService waitService, ClickStrategy clickStrategy) {
        super(findService, waitService, clickStrategy);
    }

    public void clickMegaMenu() {
        Element megaMenu = ElementFindServiceExtensions.findByXPath(findService, "//a[@class='megamenu']");
        ElementWaitServiceExtensions.waitUntilClickable(waitService, megaMenu, 2);
        clickStrategy.click(megaMenu, "Clicked on a megamenu");

    }

    public void clickSrch() {
        Element srch = ElementFindServiceExtensions.findByXPath(findService, "//input[@id='homeBannerSearch']");
        ElementWaitServiceExtensions.waitUntilClickable(waitService, srch, 2);
        clickStrategy.click(srch, "Clicked on a megamenu");

    }

}
