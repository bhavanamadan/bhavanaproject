package com.automation.core.base;

import com.automation.core.brands.HE.pages.HomePage;
import com.automation.core.config.ConfigurationService;
import com.automation.core.config.WebSettings;
import com.automation.core.driver.Driver;
import com.automation.core.driver.LoggingDriver;
import com.automation.core.driver.WebCoreDriver;
import com.automation.core.observers.BrowserLaunchTestBehaviorObserver;

import com.automation.core.reportutil.ExtentTestManager;
import com.automation.core.services.ElementFindService;
import com.automation.core.services.ElementFindServiceImpl;
import com.automation.core.services.ElementWaitService;
import com.automation.core.services.ElementWaitServiceImpl;
import com.automation.core.strategies.ClickStrategy;
import com.automation.core.strategies.LambdaClickStrategy;
import com.relevantcodes.extentreports.LogStatus;
import net.lightbody.bmp.BrowserMobProxy;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;

public class BaseTest {


//    need to use driver.remove after method and threadlocal remove for clean up after method or after suite

    protected static final WebSettings webSettings = ConfigurationService.get(WebSettings.class);

//    private static final ThreadLocal<TestExecutionSubject> executionSubject;
//    private static final ThreadLocal<Driver> driver;
//    private static final ThreadLocal<BrowserMobProxy> proxy;

    private ITestResult result;
    // Services
    protected ElementFindService findService;
    protected ElementWaitService waitService;
    protected ClickStrategy clickStrategy;

    // Page Objects
    protected HomePage homePage;

    //    static {
//        executionSubject = new ThreadLocal<>();
//        executionSubject.set(new ExecutionSubject());
//        driver = new ThreadLocal<>();
//        driver.set(new LoggingDriver(new WebCoreDriver()));
//        new BrowserLaunchTestBehaviorObserver(executionSubject.get(), driver.get());
//        proxy = new ThreadLocal<>();
//    }
    // ✅ ThreadLocal with safe initialization
    private static final ThreadLocal<TestExecutionSubject> executionSubject =
            ThreadLocal.withInitial(ExecutionSubject::new);

    private static final ThreadLocal<Driver> driver =
            ThreadLocal.withInitial(() -> new LoggingDriver(new WebCoreDriver()));

    private static final ThreadLocal<BrowserMobProxy> proxy =
            ThreadLocal.withInitial(() -> null);

    public String getTestName() {
        return getTestResult().getTestName();
    }

    public void setTestResult(ITestResult result) {
        this.result = result;
    }

    public ITestResult getTestResult() {
        return result;

    }

    public Driver getDriver() {
        return driver.get();
    }

//    @BeforeSuite
//    public void beforeSuite() {
//        ConfigManager.loadConfig(System.getProperty("env", "stg"));
//        EnvironmentConfig config = ConfigManager.getConfig();
//        String url = config.getBaseUrl();
//
//    }

    @AfterSuite

    public void afterSuite() {
        if (driver.get() != null) {
            driver.get().quit();
        }
        ExtentTestManager.flushReports(); // flush final report

    }

//    @BeforeMethod
//
//    public void beforeMethod(ITestResult result) throws NoSuchMethodException {
//        setTestResult(result);
//        // Initialize services for the current thread
//        findService = new ElementFindServiceImpl(getDriver());
//        waitService = new com.automation.core.services.ElementWaitServiceImpl(getDriver());
//        clickStrategy = new LambdaClickStrategy((element, msg) -> element.getWrappedElement().click());
//
//        // Initialize page objects
//        homePage = new HomePage(findService, waitService, clickStrategy);
//
//        // Open base URL
//        var testClass = this.getClass();
//        var methodInfo = testClass.getMethod(getTestResult().getMethod().getMethodName());
//        executionSubject.get().preTestInit(getTestResult(), methodInfo);
//        // Ensure driver is initialized for the current thread
//        if (driver.get() == null) {
//            driver.set(new LoggingDriver(new WebCoreDriver()));
//        }
//
//        // Launch the browser
//

    /// /        getDriver().start(webSettings.getDefaultBrowser());
    /// /        getDriver().goToUrl(url);  // You need a launchBrowser() method in your Driver class
//
//        testInit();
//        executionSubject.get().postTestInit(getTestResult(), methodInfo);
//    }
    @BeforeMethod
    public void beforeMethod(ITestResult result) throws NoSuchMethodException {
        setTestResult(result);
        String testName = result.getMethod().getMethodName();
        String description = result.getMethod().getDescription();
        ExtentTestManager.startTest(testName, description != null ? description : "");
        ExtentTestManager.getTest().log(LogStatus.INFO, "Starting test: " + testName);
        // Attach observers for THIS thread
        new BrowserLaunchTestBehaviorObserver(executionSubject.get(), driver.get());

        // Initialize services
        findService = new ElementFindServiceImpl(getDriver());
        waitService = new ElementWaitServiceImpl(getDriver());
        clickStrategy = new LambdaClickStrategy((element, msg) -> element.getWrappedElement().click());

        // Initialize page objects
        homePage = new HomePage(findService, waitService, clickStrategy);

        var testClass = this.getClass();
        var methodInfo = testClass.getMethod(getTestResult().getMethod().getMethodName());

        executionSubject.get().preTestInit(getTestResult(), methodInfo);

        testInit();

        executionSubject.get().postTestInit(getTestResult(), methodInfo);
    }

    //    @AfterMethod
//
//    public void afterMethod() throws NoSuchMethodException {
//        var testClass = this.getClass();
//        var methodInfo = testClass.getMethod(getTestResult().getMethod().getMethodName());
//        executionSubject.get().preTestCleanup(getTestResult(), methodInfo);
//        testCleanup();
//        executionSubject.get().postTestCleanup(getTestResult(), methodInfo);
//        executionSubject.remove();
//        driver.remove();
//        proxy.remove();
//    }
    @AfterMethod
    public void afterMethod() throws NoSuchMethodException {
        String testName = result.getMethod().getMethodName();

        if (result.getStatus() == ITestResult.SUCCESS) {
            ExtentTestManager.getTest().log(LogStatus.PASS, "Test passed: " + testName);
        } else if (result.getStatus() == ITestResult.FAILURE) {
            ExtentTestManager.getTest().log(LogStatus.FAIL, "Test failed: " + testName);
            ExtentTestManager.getTest().log(LogStatus.FAIL, result.getThrowable());
        } else if (result.getStatus() == ITestResult.SKIP) {
            ExtentTestManager.getTest().log(LogStatus.SKIP, "Test skipped: " + testName);
        }

        ExtentTestManager.endTest(); // remove from ThreadLocal map
        var testClass = this.getClass();
        var methodInfo = testClass.getMethod(getTestResult().getMethod().getMethodName());

        executionSubject.get().preTestCleanup(getTestResult(), methodInfo);

        testCleanup();

        executionSubject.get().postTestCleanup(getTestResult(), methodInfo);

        // ✅ Important cleanup for parallel runs
        executionSubject.remove();
        driver.remove();
        proxy.remove();
    }

    protected void testInit() {
        // custom setup for child test classes


    }

    protected void testCleanup() {
        // custom setup for child test classes

    }
}