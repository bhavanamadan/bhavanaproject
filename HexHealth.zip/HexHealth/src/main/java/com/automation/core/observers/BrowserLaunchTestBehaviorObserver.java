package com.automation.core.observers;

import com.automation.core.config.ConfigurationService;
import com.automation.core.config.WebSettings;
import com.automation.core.driver.Driver;
import com.automation.core.annotations.ExecutionBrowser;
import com.automation.core.base.BaseTestBehaviorObserver;
import com.automation.core.base.TestExecutionSubject;
import com.automation.core.config.BrowserConfiguration;
import com.automation.core.enums.Browser;
import com.automation.core.enums.BrowserBehavior;
import org.testng.ITestResult;

import java.lang.reflect.Method;
import java.util.Optional;

public class BrowserLaunchTestBehaviorObserver extends BaseTestBehaviorObserver {


    // Make these ThreadLocal to ensure thread safety in parallel runs
    private final ThreadLocal<Driver> driver;
    private final ThreadLocal<BrowserConfiguration> currentBrowserConfiguration;
    private final ThreadLocal<BrowserConfiguration> previousBrowserConfiguration;

    public BrowserLaunchTestBehaviorObserver(TestExecutionSubject testExecutionSubject, Driver driver) {
        super(testExecutionSubject);
        this.driver = ThreadLocal.withInitial(() -> driver);
        this.currentBrowserConfiguration = new ThreadLocal<>();
        this.previousBrowserConfiguration = new ThreadLocal<>();
    }

    @Override
    public void preTestInit(ITestResult testResult, Method memberInfo) {
        BrowserConfiguration config = getBrowserConfiguration(memberInfo);
        currentBrowserConfiguration.set(config);

        Boolean shouldRestartBrowser = shouldRestartBrowser(config);
        if (shouldRestartBrowser) {
            restartBrowser();
        }
        previousBrowserConfiguration.set(config);
    }

    @Override
    public void postTestCleanup(ITestResult testResult, Method memberInfo) {
        BrowserConfiguration config = currentBrowserConfiguration.get();
        if (config != null &&
                config.getBrowserBehavior() == BrowserBehavior.RESTART_ON_FAIL &&
                testResult.getStatus() == ITestResult.FAILURE) {
            restartBrowser();
        }
        // Always clean ThreadLocals to avoid memory leaks
        currentBrowserConfiguration.remove();
        previousBrowserConfiguration.remove();
        driver.remove(); // safe even if driver is not restarted
    }

    private void restartBrowser() {
        driver.get().quit();
        driver.get().start(currentBrowserConfiguration.get().getBrowser());
    }

    private Boolean shouldRestartBrowser(BrowserConfiguration browserConfiguration) {
        if (previousBrowserConfiguration.get() == null) {
            return true;
        }
        return browserConfiguration.getBrowserBehavior() == BrowserBehavior.RESTART_EVERY_TIME
                || browserConfiguration.getBrowserBehavior() == BrowserBehavior.NOT_SET;
    }

    private BrowserConfiguration getBrowserConfiguration(Method memberInfo) {
        return Optional.ofNullable(getExecutionBrowserMethodLevel(memberInfo))
                .orElse(Optional.ofNullable(getExecutionBrowserClassLevel(memberInfo.getDeclaringClass()))
                        .orElseGet(this::getDefaultBrowserConfiguration));
    }

    private BrowserConfiguration getDefaultBrowserConfiguration() {
        WebSettings settings = ConfigurationService.get(WebSettings.class);
        Browser defaultBrowser = Browser.fromText(settings.getDefaultBrowser());
        return new BrowserConfiguration(defaultBrowser, BrowserBehavior.NOT_SET);
    }

    private BrowserConfiguration getExecutionBrowserMethodLevel(Method memberInfo) {
        var executionBrowserAnnotation = memberInfo.getDeclaredAnnotation(ExecutionBrowser.class);
        if (executionBrowserAnnotation == null) {
            return null;
        }
        return new BrowserConfiguration(
                executionBrowserAnnotation.browser(),
                executionBrowserAnnotation.browserBehavior()
        );
    }

    private BrowserConfiguration getExecutionBrowserClassLevel(Class<?> type) {
        var executionBrowserAnnotation = type.getDeclaredAnnotation(ExecutionBrowser.class);
        if (executionBrowserAnnotation == null) {
            return null;
        }
        return new BrowserConfiguration(
                executionBrowserAnnotation.browser(),
                executionBrowserAnnotation.browserBehavior()
        );
    }
}
