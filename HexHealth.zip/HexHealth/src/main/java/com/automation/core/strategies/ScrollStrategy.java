package com.automation.core.strategies;

import org.openqa.selenium.WebElement;

public interface ScrollStrategy {
    void scroll(WebElement element);

}
