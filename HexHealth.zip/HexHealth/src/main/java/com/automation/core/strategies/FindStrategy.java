package com.automation.core.strategies;

import org.openqa.selenium.By;

public interface FindStrategy {
    By convert(); // returns Selenium By

}
