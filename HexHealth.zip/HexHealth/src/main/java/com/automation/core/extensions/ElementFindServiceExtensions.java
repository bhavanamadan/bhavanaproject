package com.automation.core.extensions;

import com.automation.core.elements.Element;
import com.automation.core.services.ElementFindService;
import com.automation.core.strategies.LambdaFindStrategy;
import org.openqa.selenium.By;

import java.util.List;

public class ElementFindServiceExtensions {
    private ElementFindServiceExtensions() {
        throw new UnsupportedOperationException("Utility class - do not instantiate");
    }

    public static Element findById(ElementFindService service, String id) {
        return service.find(new LambdaFindStrategy(() -> By.id(id)));
    }

    public static Element findByXPath(ElementFindService service, String xpath) {
        return service.find(new LambdaFindStrategy(() -> By.xpath(xpath)));
    }

    public static Element findByDataTestId(ElementFindService service, String testId) {
        return service.find(new LambdaFindStrategy(() -> By.cssSelector("[data-test-id='" + testId + "']")));
    }

    public static Element findByRole(ElementFindService service, String role) {
        return service.find(new LambdaFindStrategy(() -> By.cssSelector("[role='" + role + "']")));
    }

    public static List<Element> findAllByClass(ElementFindService service, String className) {
        return service.findAll(new LambdaFindStrategy(() -> By.className(className)));
    }
}
