package com.automation.core.services;

import com.automation.core.driver.Driver;
import com.automation.core.elements.Element;
import com.automation.core.services.ElementFindService;
import com.automation.core.strategies.FindStrategy;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.stream.Collectors;

public class ElementFindServiceImpl implements ElementFindService {

    private final Driver driver;  // use your framework Driver abstraction

    public ElementFindServiceImpl(Driver driver) {
        this.driver = driver;
    }

    @Override
    public Element find(FindStrategy strategy) {
        WebElement el = driver.getWrappedDriver().findElement(strategy.convert());
        return new Element(el, strategy.convert()); // store both WebElement and locator
    }

    @Override
    public List<Element> findAll(FindStrategy strategy) {
        return driver.getWrappedDriver()
                .findElements(strategy.convert())
                .stream()
                .map(el -> new Element(el, strategy.convert()))
                .collect(Collectors.toList());
    }
}
