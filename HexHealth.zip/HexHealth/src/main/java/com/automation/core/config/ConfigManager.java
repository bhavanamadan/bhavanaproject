package com.automation.core.config;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class ConfigManager {

    private static final ThreadLocal<EnvironmentConfig> threadLocalConfig = new ThreadLocal<>();

    private ConfigManager() {}

    public static void loadConfig(String env) {
        if (threadLocalConfig.get() == null) {
            synchronized (ConfigManager.class) {
                if (threadLocalConfig.get() == null) {
                    threadLocalConfig.set(loadFromProperties(env));
                }
            }
        }
    }

    private static EnvironmentConfig loadFromProperties(String env) {
        Properties props = new Properties();
        try (InputStream input = ConfigManager.class.getClassLoader()
                .getResourceAsStream(env + ".properties")) {
            if (input == null) {
                throw new RuntimeException("Config file not found: " + env + ".properties");
            }
            props.load(input);
        } catch (IOException e) {
            throw new RuntimeException("Failed to load config: " + env, e);
        }

        return new EnvironmentConfig(
                props.getProperty("base.url"),
                props.getProperty("browser", "chrome"),
                Integer.parseInt(props.getProperty("timeout", "30")),
                Boolean.parseBoolean(props.getProperty("headless", "false"))
        );
    }

    public static EnvironmentConfig getConfig() {
        EnvironmentConfig config = threadLocalConfig.get();
        if (config == null) {
            throw new IllegalStateException("Config not loaded. Call loadConfig(env) first.");
        }
        return config;
    }

    public static void clearConfig() {
        threadLocalConfig.remove();
    }
}
